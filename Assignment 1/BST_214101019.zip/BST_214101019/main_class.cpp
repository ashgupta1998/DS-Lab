#include <iostream>
#include <stdio.h>
#include <cstdlib>



using namespace std;

	int count =0;			//stores the number of nodes in the tree		

	class list				//list depicts the node of a linked list.It is user defined function as stl is not used 
	{
		public:
			int data;
			list * next;
			list(){
				next = NULL;
			}
			
	};

	class linked_list
	{

    	public: 
			list * head;
			linked_list()						//constructor to initialize head as null
			{
				head = NULL;
			}
			
			void insert_at_beginning(int a)		//to insert at the beginning of the list
			{
				list * temp = new list();
				temp->data =a;
				temp->next = head;
				head = temp;
			}
			
			void insert_at_end(int a)			//to insert at the end of the list
			{
				list * temp = new list();
				temp->data = a;
				if(head == NULL)
					head = temp;
				else
				{
					list * ptr = head;
					while(ptr->next != NULL)
					{
						ptr = ptr->next;
					}
					ptr->next = temp;
				}
			}
		
			void print()						//to print the elements of the linked list
			{
				if (head == NULL)
					cout<<"List is empty"<<endl;

				else
				{
					list *ll_temp = head;
					cout<<"Linked List: ";
					while (ll_temp != NULL)
					{
						cout<<ll_temp->data<<" ";
						ll_temp = ll_temp->next;
					}
					
				}
			}	
	
 };
	struct Node								//to represent node of the tree
	{
		int data;
		struct Node *left;
		struct Node *right;
		bool rightThread;
	};
	Node *root=NULL,*root1=NULL,*root2=NULL;

	

	class BST_op							
	{
		public:
		
	
		BST_op ()							//constructor to initialize root to null
		{
			root = NULL;

		}
		
		Node* insert(struct Node *root, int x);
		Node * search(struct Node *root, int x,bool flag);
		Node* delete_node(struct Node *root, int x);
		list * reverseinorder(struct Node * root);
		Node* inorderSuccessor(Node *root);
		list* allElementsBetween(struct Node* root,int k1,int  k2);
		Node * split(struct Node *root, int k);
		int kthLargestElement(struct Node * root,int largest);
		int bst_print(Node* root,FILE *stream);
		void printpre(struct Node* root);
		void inorder(struct Node *root);

	};

//        *****************************************Functions***************************************************************************     //


	Node * create (int x)								//for initialization of a tree node //single threaded BST implemented
	{
		Node *temp = new Node();
		temp->data = x;
		temp->left = temp->right = NULL;
		temp->rightThread = false;
		return temp;
	}



	Node * BST_op::inorderSuccessor(struct Node *root)
	{
		// Returns inorder successor 
	    
	    
	    Node* ptr = new Node();
	    ptr = root;
	    //if right thread is true then return right pointer
	    if (ptr -> rightThread == true)
	        return ptr->right;
	 
	    // Else return leftmost child of right subtree
	    ptr = ptr -> right;
	    while (ptr -> left != NULL)
	        ptr = ptr -> left;
	    return ptr;
	}

	void BST_op :: inorder(struct Node *root)
	{
	    if (root == NULL)
	        printf("Tree is empty");
	 
	    
	    struct Node *temp = root;
	    while (temp -> left != NULL)			// Move to the leftmost node of the tree
	        temp = temp -> left;
	 
	    //start printing the successors
	    while (temp != NULL)
	    {
	    	cout<<temp->data<<" ";
	        temp = inorderSuccessor(temp);
	    }
	}


	list * BST_op :: reverseinorder(struct Node *root)
	{
		if (root == NULL)
	        printf("Tree is empty");
	 
	 	linked_list ll;										
	    struct Node *temp = root,*parent;
	    
	    
		while(temp->left!=NULL)						// Move to the leftmost node of the tree
		{
			
			temp = temp -> left;
		}
												//Insert successors at the beginning of the list to get in reverse order
	    while(temp->right!=NULL)
	    {
	    	ll.insert_at_beginning(temp->data);
	        temp = inorderSuccessor(temp);
	    }
	    ll.insert_at_beginning(temp->data);
	    cout<<"Linked List : ";
	    list *ll_ptr ;
	    ll_ptr = ll.head;
	    while(ll_ptr != NULL)
	    {
	    	cout<<ll_ptr->data<<" ";
	    	ll_ptr = ll_ptr ->next;
		}
		cout<<endl;
	    return ll.head;								//return head of the list
	}
	 

	Node* BST_op:: insert(struct Node * root, int x)
	{
		
		Node *temp = new Node();
		temp = root;
		bool flag = false;
		
		
		if(root == NULL)			//if tree is uninitialized then initiliaze it 
		{
			root = create(x);
			flag = true;
			count++;
			cout<<"Data inserted"<<endl;
			return root;
		}
		else{
			
			Node *parent = new Node();
			while(temp!=NULL)
			{
				if(temp->data == x)
				{
					flag = false;
					cout<<x<<" Data already exists !!"<<endl;
					return root;
				}
				else if(temp->data > x)
				{
					parent=temp;
					temp = temp->left;
				}
				else
				{
					parent=temp;
					if(temp->rightThread == false)			//if thread is false then move to the righ child
						temp = temp->right;
					else 
						break;
				}
				
			}
			count++;									//as node inserted increment count
			cout<<"Data inserted !!"<<endl;
			
			Node *node = create(x);
	
			
			if(parent->data < x)					   		//inserted as right child of parent
			{
				parent->rightThread = false;
				node->rightThread = true;
				node->right = parent->right;
				parent->right = node;
				
			}
			else										//inserted as left child of "<<parent
			{
				node->rightThread = true;
				node->right = parent;
				parent->left = node;
				
			}
			flag = true;
			return root;
		}
	}
	
	
	Node * BST_op :: search(struct Node * root, int x,bool flag)		//search if not present in the tree or not flag states whether or not comment is to be printed
	{
		Node *temp = new Node();
		temp = root;
		if(temp == NULL)
			return NULL;
		else
		{
		while(temp != NULL)
		{
		if(temp->data == x)
		{
			if(flag)
		    cout<<"data found !!"<<endl;
			return temp;
		}
		else if(x < temp->data)
		{
			temp = temp->left;
		}
		else
		{
			if(temp->rightThread == true)
			{
				if(flag)
				cout<<"Data not found"<<endl;
				return NULL;
		    }
		    else{
		    	temp = temp->right;
		    }
		}
		}
		
	 }
	 if(flag)
	 cout<<"data not found"<<endl;
	 return NULL;    
	}

int BST_op:: kthLargestElement(struct Node* root,int largest)
{
	struct Node * ptr;
	ptr = root;
	BST_op obj2;
	if(root == NULL)
	{
		cout<<"Tree is empty"<<endl;
		return 0;
	}
	else
	{
		while(ptr->left !=NULL)					//move to the leftmost node
		{
			ptr = ptr->left;
		}
		int i=1;
		for(i=1;i<=largest;i++)
		{
			ptr = obj2.inorderSuccessor(ptr);		//call successors
		}
		return ptr->data;
 	}
}


list * BST_op :: allElementsBetween(struct Node* root,int k1,int  k2)
{
	linked_list ll ;
	struct Node *temp,*parent;
	temp = root;
	
	bool flag = true;
	cout<<"entered"<<endl;
	if(root == NULL)
	{
		cout<<"Tree is empty"<<endl;
		return NULL;
	}
	else
	{
		
		while(temp != NULL && flag)					//move to the smallest node whose value is greater or equal to k1
		{
			if(temp->data == k1)
			{
	    		flag = false;
			}
			else if(k1 < temp->data)
			{
				parent = temp;
				temp = temp->left;
			}
			else
			{
				if(temp->rightThread == true)
					{
						flag = false;
	    			}
	   			 else{
	    			temp = temp->right;
	   			 }
			}
	}
	
	
	if(flag == true)
	{
		temp = parent;
		ll.insert_at_end(parent->data);
    } 
	
	if(flag == false && temp->rightThread != false || &(temp->data)!=0 && flag == false )			
	{
		
		if(temp->data == k1  )
			{
				ll.insert_at_end(k1);							// if k1 exists and we have reached at it then insert it 
			}
	}
			temp = inorderSuccessor(temp);						//if suppose k1 does not exist then since we have reached at the smallest node whose value is greater than equal to k1 so insert that node value in the list 
			
			while(temp!=NULL && temp->data <= k2 )				//keep inserting inorder successors until the value <=k2
			{
				ll.insert_at_end(temp->data);
				temp = inorderSuccessor(temp);
			}
	}
	
			
			
	
	
	ll.print();
	return ll.head;											//return list header
}


 Node * BST_op :: delete_node(struct Node *root, int x)
{
	struct Node * temp,*parent;
	temp = root;
	parent = temp;
	if(root!=NULL)
	{
		while(temp->data !=x)
		{
			parent = temp;
			if(temp->data < x)
			{
				temp = temp->right;
			}
			else
			{
				temp = temp->left;
			}
		}
		
	if(temp->left== NULL)
	{
		if(temp->rightThread == false && temp->right == NULL)			//rightmost node of the tree with no left child 
		{
			parent ->right = NULL;
			
			free(temp);
			return root;
		}
		else if(temp->rightThread == true)					//leaf node
		{
			if(parent->right == temp)					//temp as right child of its parent 
			{
				parent->rightThread = true;
				parent->right = temp->right;
				temp = NULL;
				free(temp);
				return root;
			}
			else									//temp as left child of its parent
			{
				parent->left = NULL;
				free (temp);
				return root;
			}
		}
		else
		{
			if(temp->rightThread == false && temp->right != NULL)		//temp has right child and no left child 
			{
				if(parent->right == temp)								//temp is right child of its parent so parent->right will now point to temp->right
				{
					parent->right = temp->right;
					free(temp);
					return root;
				}
				else{													//temp is left child of its parent so parent->left will now point to temp->right
					parent->left = temp->right;
					free(temp);
					return root;
				}
		}
	}
}
	else
	{
		if(temp->rightThread == true)				//node to be deleted has only left child and no right child
			{
			 if(parent->left == temp)
			  {
				if((temp->left)->right == temp)			//left child of temp has no right child
				{
					(temp->left)->right=parent;
				}
				parent->left = temp->left;
				free(temp);
				return root;
			 }
			else{
				if((temp->left)->right == temp)
				{
					(temp->left)->right = NULL;
					(temp->left)->rightThread = false;
				}
				parent->right = temp->left;
				free(temp);
				return root;
			}
		}
			else if(temp->rightThread == false && temp->right== NULL)	//rightmost node of tree with left child
				{
				if(((temp->left)->right) == temp && (temp->left)->rightThread == true)
				{
					(temp->left)->right = NULL;
					(temp->left)->rightThread = false;
				}
				parent->right = temp->left;
				free(temp);
				return root;
				}
			else{												//both child exists
				Node * temp_new;
				temp_new = inorderSuccessor(temp);
				temp = delete_node(temp,temp_new->data);
				temp->data = temp_new->data;				//copy inorder successors value
				free(temp_new);
				return root;
			}
}
}

else{
	cout<<"Tree is Empty";
	return NULL;
}
}
				


Node * BST_op:: split(struct Node *root, int k)
{
	struct Node *temp;
	temp = root;
	BST_op bst1;
	BST_op bst2;
	if(root == NULL)
	{
		cout<<"Tree is empty"<<endl;
		return NULL;
	}
	else
	{
		int c=1;
		while(temp->right != NULL)
		{
			if(temp->data <= k)
			{
				if(!bst1.search(root1,temp->data,false))					//node inserted for the first time
				  {
					root1 = bst1.insert(root1,temp->data);
					c = 1;
				  }
				else
					c=2;													//node already exists
			}
			else
			{	if(!bst2.search(root2,temp->data,false))				
				{
					root2 = bst2.insert(root2,temp->data);
					c = 1;
				  }
				else
					c=2;
			}
			if(c==1)
			{
				if(temp->left != NULL )
				{
					temp = temp->left;
				}
				else if(temp->left == NULL && temp->rightThread == true )
				{
					temp = inorderSuccessor(temp);
					temp = inorderSuccessor(temp);
				}
				else
					if(temp->left == NULL && temp->rightThread == false)
					 {
						temp = inorderSuccessor(temp);
			 		 }
			}
			else
				{
					temp = temp->right;
				}
			}
		}
				cout<<"Inorder traversal of Tree 1: ";
				bst1.inorder(root1);
				cout<<"\nInorder traversal of Tree 2: ";
				bst2.inorder(root2);
				return root;
				
			}
			
			



void bst_print_null(int key, int nullcount, FILE* fptr)
{
    fprintf(fptr, "    null%d [shape=point];\n", nullcount);
    fprintf(fptr, "    %d -> null%d;\n", key, nullcount);
}

void bst_print2(Node* node, FILE* fptr)
{
    static int nullcount = 0;

    if (node->left)
    {
        fprintf(fptr, "    %d -> %d;\n", node->data, node->left->data);
        bst_print2(node->left, fptr);
    }
    else
        bst_print_null(node->data, nullcount++, fptr);

    if (node->right && node->rightThread == false)
    {
        fprintf(fptr, "    %d -> %d;\n", node->data, node->right->data);
        bst_print2(node->right, fptr);
    }
    else
        bst_print_null(node->data, nullcount++, fptr);
}

void bst_print(Node* tree, FILE* fptr)
{
    fprintf(fptr, "digraph BST {\n");
    fprintf(fptr, "    node [fontname=\"Arial\"];\n");

    if (!tree)
        fprintf(fptr, "\n");
    else if (!tree->right && !tree->left)
        fprintf(fptr, "    %d;\n", tree->data);
    else
        bst_print2(tree, fptr);

    fprintf(fptr, "}\n");
}


int main(int argc, char** argv) {
	
	int ch;
	BST_op obj;
	char c;
	
	do
	{
	cout<<"\nChoose 1. Insert 2. Search 3. Delete 4. reverse inorder 5. Successor  6. Split 7. Elements between (k1,k2) \n 8. kthlargestelement 9. print 10.exit"<<endl;
	cout<<"Enter choice: ";
	cin>>ch;
	switch (ch){
	case 1:
		
		cout<<"Enter value: ";
		int x;
		cin>>x;
		root = obj.insert(root,x);
		break;
	case 2: 
		cout<<"Enter value: ";
		int y;
		cin>>y;
		Node *t;
		t = obj.search(root,y,true);
		cout<<&(t->data)<<endl;
		break;
		
	case 3:
		cout<<"Enter value: ";
		int d;
		cin>>d;
		Node * del_search;
		del_search = obj.search(root,d,false);
		if(del_search != NULL)
		{
			root = obj.delete_node(root,d);
			count--;
			
		}
		break;
		
	case 4:
		list * list_rev_inorder;
		list_rev_inorder = obj.reverseinorder(root);
		break;
	
	case 5:
		cout<<"Enter value: ";
		int z;
		cin>>z;
		Node *a;
		a = obj.search(root,z,false);
		if(a == NULL)
		{
			break;
		}
		else if(a->right == NULL || &(a->data) == 0 ){
		
			cout<<"no inorder successor exists "<<endl;
			break;
			}
		
		else
		{
		a = obj.inorderSuccessor(a);
		cout<<"inorder successor of "<<z <<" is "<<a->data<<endl;
	    }
		break;
	
	case 6:
		int k;
		cout<<"Enter value: ";
		cin>>k;
		root = obj.split(root,k);
		break;
	
	case 7:
		int k1,k2;
		cout<<"Enter k1: ";
		cin>>k1;
		cout<<"Enter k2: ";
		cin>>k2;
		
		list * elements_between_k1k2;
		elements_between_k1k2 = obj.allElementsBetween(root,k1,k2);
		break;
	
	case 8:
		int largest;
		cout<<"Enter value: ";
		cin>>largest;
		int kth_largest ;
		cout<<"number of nodes = "<<count<<endl;
		kth_largest = obj.kthLargestElement(root,count-largest);
		cout<<"kth largest element is "<<kth_largest<<endl;
		break;
	case 9:
		FILE *fptr;
		fptr = fopen("graph.graphviz.txt","w");
		
		bst_print(root ,fptr);
		fclose(fptr);
		break;
			
	case 10:
		cout<<"printing tree"<<endl;
		//obj.printpre(root);
		break;
		}
		cout<<"\nStart again y/n: ";
		cin>>c;
		
	
}while(c=='y');


cout<<"Exiting !!"<<endl;
	return 0;
}

