DS LAB ASSIGNMENT 1 

Steps to run code:

1. Open the code in DevC++
2. Compile and Run
3. Enter the choice number (like 1. to insert, 2 to search ,3 to delete ,...) of the operation you want to perform 
4. Once done press y to do more operations and n to stop performing operations.
5. If tree is to be printed after pressing 9 , graph.graphiz.txt file will be created
6. Create a folder named graph 
7. In that put the graph.graphiz.txt file 
8. open command prompt 
9. type "GRAPHVIZ-BIN-DOT.EXE-LOCATION" -Tsvg GRAPH.GRAPHVIX.TXT LOCATION -o FOLDER LOCATION FOLLOWED BY GRAPH.SVG

Eg. "C:\Program Files\Graphviz\bin\dot.exe" -Tsvg C:\ASHU\graph\graph.graphviz.txt -o C:\ASHU\graph\graph.graph.svg

10. now open .svg file to view the graph 





Note:
for inserting and thus creating a tree you may use following inputs 
1
20
y
1
10
y
1
5
y
1
16
y
1
30

